#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <chrono>
#include <random>
#include <cassert>

using Matrix = std::vector<std::vector<double>>;

Matrix random_matrix(size_t N) {
    std::mt19937_64 rng(42);
    std::uniform_real_distribution<double> dist(0.0, 1.0);
    Matrix M(N, std::vector<double>(N));
    for (size_t i = 0; i < N; ++i)
        for (size_t j = 0; j < N; ++j)
            M[i][j] = dist(rng);
    return M;
}
void multiply_subblock(
        const Matrix& A, const Matrix& B, Matrix& C,
        size_t row_start, size_t col_start, size_t k_start,
        size_t block, size_t N,
        std::mutex& mtx)
{
    size_t row_end = std::min(row_start + block, N);
    size_t col_end = std::min(col_start + block, N);
    size_t k_end   = std::min(k_start   + block, N);

    for (size_t i = row_start; i < row_end; ++i) {
        for (size_t j = col_start; j < col_end; ++j) {
            double sum = 0.0;
            for (size_t k = k_start; k < k_end; ++k) {
                sum += A[i][k] * B[k][j];
            }
            if (sum != 0.0) {
                std::lock_guard<std::mutex> lock(mtx);
                C[i][j] += sum;
            }
        }
    }
}
Matrix multiply_threaded(const Matrix& A, const Matrix& B, size_t block)
{
    size_t N = A.size();
    Matrix C(N, std::vector<double>(N, 0.0));

    size_t blocks = (N + block - 1) / block;        
    std::vector<std::thread> threads;
    std::mutex mtx;

    for (size_t bi = 0; bi < blocks; ++bi) {
        for (size_t bj = 0; bj < blocks; ++bj) {
            for (size_t bk = 0; bk < blocks; ++bk) {
                size_t row_start = bi * block;
                size_t col_start = bj * block;
                size_t k_start   = bk * block;
                threads.emplace_back(
                    multiply_subblock,
                    std::cref(A), std::cref(B), std::ref(C),
                    row_start, col_start, k_start, block, N,
                    std::ref(mtx)
                );
            }
        }
    }

    for (auto& t : threads) t.join();
    return C;
}

Matrix multiply_naive(const Matrix& A, const Matrix& B)
{
    size_t N = A.size();
    Matrix C(N, std::vector<double>(N, 0.0));
    for (size_t i = 0; i < N; ++i)
        for (size_t j = 0; j < N; ++j)
            for (size_t k = 0; k < N; ++k)
                C[i][j] += A[i][k] * B[k][j];
    return C;
}

int main(int argc, char** argv)
{
    size_t N = (argc > 1) ? std::stoul(argv[1]) : 10;
    if (N < 5) N = 5;

    Matrix A = random_matrix(N);
    Matrix B = random_matrix(N);

    auto t0 = std::chrono::high_resolution_clock::now();
    auto C_ref = multiply_naive(A, B);
    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "Naive multiplication time: "
              << std::chrono::duration<double>(t1 - t0).count() << " s\n";

    std::cout << "block_size,threads,time\n";
    for (size_t block = 1; block <= N; ++block) {
        size_t blocks = (N + block - 1) / block;
        size_t thread_cnt = blocks * blocks * blocks;     

        t0 = std::chrono::high_resolution_clock::now();
        auto C = multiply_threaded(A, B, block);
        t1 = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(t1 - t0).count();

        std::cout << block << "," << thread_cnt << "," << elapsed << "\n";

        if (N <= 10 && C != C_ref) {
            std::cerr << "Mismatch detected for block " << block << "\n";
            return 1;
        }
    }
    return 0;
}
