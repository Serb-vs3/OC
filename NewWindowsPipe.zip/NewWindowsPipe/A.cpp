#include <iostream>
int main(){const long long N=4;long long x;while(std::cin>>x){std::cout<<x+N<<' ';}return 0;}
