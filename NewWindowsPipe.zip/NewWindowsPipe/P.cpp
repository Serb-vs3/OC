#include <iostream>
int main(){long long x;while(std::cin>>x){std::cout<<x*x*x<<' ';}return 0;}
