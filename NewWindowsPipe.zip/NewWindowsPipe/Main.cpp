#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <filesystem>

static bool dup_inherit(HANDLE src, HANDLE& dst) {
    return DuplicateHandle(GetCurrentProcess(), src, GetCurrentProcess(), &dst, 0, TRUE, DUPLICATE_SAME_ACCESS) != 0;
}

static HANDLE spawn(const std::wstring& exePath, HANDLE inH, HANDLE outH) {
    STARTUPINFOW si{};
    PROCESS_INFORMATION pi{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = inH;
    si.hStdOutput = outH;
    si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    std::wstring cmd = L"\"" + exePath + L"\"";
    std::vector<wchar_t> buf(cmd.begin(), cmd.end());
    buf.push_back(L'\0');

    if (!CreateProcessW(exePath.c_str(), buf.data(), nullptr, nullptr, TRUE, 0, nullptr, nullptr, &si, &pi)) {
        return nullptr;
    }

    CloseHandle(pi.hThread);
    return pi.hProcess;
}

int wmain() {
    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = nullptr;
    sa.bInheritHandle = FALSE;

    HANDLE p0_r, p0_w, p1_r, p1_w, p2_r, p2_w, p3_r, p3_w, p4_r, p4_w;
    if (!CreatePipe(&p0_r, &p0_w, &sa, 0)) return 1;
    if (!CreatePipe(&p1_r, &p1_w, &sa, 0)) return 1;
    if (!CreatePipe(&p2_r, &p2_w, &sa, 0)) return 1;
    if (!CreatePipe(&p3_r, &p3_w, &sa, 0)) return 1;
    if (!CreatePipe(&p4_r, &p4_w, &sa, 0)) return 1;

    wchar_t modulePath[MAX_PATH];
    DWORD n = GetModuleFileNameW(nullptr, modulePath, MAX_PATH);
    if (n == 0 || n == MAX_PATH) return 1;

    std::filesystem::path exeDir = std::filesystem::path(modulePath).parent_path();
    std::wstring mPath = (exeDir / L"M.exe").wstring();
    std::wstring aPath = (exeDir / L"A.exe").wstring();
    std::wstring pPath = (exeDir / L"P.exe").wstring();
    std::wstring sPath = (exeDir / L"S.exe").wstring();

    HANDLE m_in, m_out, a_in, a_out, p_in, p_out, s_in, s_out;
    if (!dup_inherit(p0_r, m_in)) return 1;
    if (!dup_inherit(p1_w, m_out)) return 1;
    if (!dup_inherit(p1_r, a_in)) return 1;
    if (!dup_inherit(p2_w, a_out)) return 1;
    if (!dup_inherit(p2_r, p_in)) return 1;
    if (!dup_inherit(p3_w, p_out)) return 1;
    if (!dup_inherit(p3_r, s_in)) return 1;
    if (!dup_inherit(p4_w, s_out)) return 1;

    std::vector<HANDLE> procs;
    procs.push_back(spawn(mPath, m_in, m_out));
    procs.push_back(spawn(aPath, a_in, a_out));
    procs.push_back(spawn(pPath, p_in, p_out));
    procs.push_back(spawn(sPath, s_in, s_out));

    CloseHandle(m_in); CloseHandle(m_out);
    CloseHandle(a_in); CloseHandle(a_out);
    CloseHandle(p_in); CloseHandle(p_out);
    CloseHandle(s_in); CloseHandle(s_out);

    CloseHandle(p0_r);
    CloseHandle(p1_r); CloseHandle(p1_w);
    CloseHandle(p2_r); CloseHandle(p2_w);
    CloseHandle(p3_r); CloseHandle(p3_w);
    CloseHandle(p4_w);

    std::string input((std::istreambuf_iterator<char>(std::cin)), std::istreambuf_iterator<char>());
    DWORD written = 0;
    if (!input.empty()) {
        WriteFile(p0_w, input.data(), (DWORD)input.size(), &written, nullptr);
    }
    CloseHandle(p0_w);

    std::string output;
    char bufc[4096];
    DWORD readn = 0;
    while (ReadFile(p4_r, bufc, sizeof(bufc), &readn, nullptr) && readn > 0) {
        output.append(bufc, bufc + readn);
    }
    CloseHandle(p4_r);

    std::cout << output;

    for (HANDLE h : procs) {
        if (!h) continue;
        WaitForSingleObject(h, INFINITE);
        CloseHandle(h);
    }
    return 0;
}
