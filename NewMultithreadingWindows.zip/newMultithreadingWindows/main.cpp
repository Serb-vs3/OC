#define NOMINMAX
#include <windows.h>
#include <vector>
#include <iostream>
#include <random>
#include <chrono>
#include <string>
#include <algorithm>

using Matrix = std::vector<std::vector<double>>;

Matrix random_matrix(size_t N, uint64_t seed) {
    std::mt19937_64 rng(seed);
    std::uniform_real_distribution<double> dist(0.0, 1.0);
    Matrix M(N, std::vector<double>(N));
    for (size_t i = 0; i < N; ++i)
        for (size_t j = 0; j < N; ++j)
            M[i][j] = dist(rng);
    return M;
}

struct ThreadData {
    const Matrix* A;
    const Matrix* B;
    Matrix* C;
    size_t row;
    size_t col;
    size_t block;
    size_t N;
    CRITICAL_SECTION* cs;
};

DWORD WINAPI multiply_block(LPVOID param) {
    ThreadData* d = static_cast<ThreadData*>(param);
    const size_t row_end = std::min(d->row + d->block, d->N);
    const size_t col_end = std::min(d->col + d->block, d->N);
    const size_t tile_rows = row_end - d->row;
    const size_t tile_cols = col_end - d->col;

    std::vector<double> tile(tile_rows * tile_cols, 0.0);

    for (size_t kk = 0; kk < d->N; kk += d->block) {
        const size_t k_end = std::min(kk + d->block, d->N);
        for (size_t i = d->row; i < row_end; ++i) {
            const size_t ti = (i - d->row) * tile_cols;
            for (size_t k = kk; k < k_end; ++k) {
                const double aik = (*d->A)[i][k];
                const auto& Brow = (*d->B)[k];
                for (size_t j = d->col; j < col_end; ++j) {
                    tile[ti + (j - d->col)] += aik * Brow[j];
                }
            }
        }
    }

    EnterCriticalSection(d->cs);
    for (size_t i = d->row; i < row_end; ++i) {
        const size_t ti = (i - d->row) * tile_cols;
        for (size_t j = d->col; j < col_end; ++j) {
            (*d->C)[i][j] = tile[ti + (j - d->col)];
        }
    }
    LeaveCriticalSection(d->cs);

    return 0;
}

Matrix multiply_windows(const Matrix& A, const Matrix& B, size_t block) {
    const size_t N = A.size();
    Matrix C(N, std::vector<double>(N, 0.0));

    CRITICAL_SECTION cs;
    InitializeCriticalSection(&cs);

    const size_t blocks = (N + block - 1) / block;
    const size_t thread_cnt = blocks * blocks;

    std::vector<HANDLE> handles;
    handles.reserve(thread_cnt);
    std::vector<ThreadData> td;
    td.reserve(thread_cnt);

    for (size_t row = 0; row < N; row += block) {
        for (size_t col = 0; col < N; col += block) {
            td.push_back(ThreadData{&A, &B, &C, row, col, block, N, &cs});
            HANDLE h = CreateThread(nullptr, 0, multiply_block, &td.back(), 0, nullptr);
            if (h) handles.push_back(h);
        }
    }

    const DWORD max_wait = MAXIMUM_WAIT_OBJECTS;
    for (size_t offset = 0; offset < handles.size();) {
        DWORD cnt = static_cast<DWORD>(std::min<size_t>(max_wait, handles.size() - offset));
        WaitForMultipleObjects(cnt, handles.data() + offset, TRUE, INFINITE);
        offset += cnt;
    }

    for (HANDLE h : handles) CloseHandle(h);
    DeleteCriticalSection(&cs);

    return C;
}

Matrix multiply_naive(const Matrix& A, const Matrix& B) {
    const size_t N = A.size();
    Matrix C(N, std::vector<double>(N, 0.0));
    for (size_t i = 0; i < N; ++i)
        for (size_t k = 0; k < N; ++k) {
            const double aik = A[i][k];
            const auto& Brow = B[k];
            for (size_t j = 0; j < N; ++j)
                C[i][j] += aik * Brow[j];
        }
    return C;
}

int main(int argc, char** argv) {
    size_t N = (argc > 1) ? static_cast<size_t>(std::stoull(argv[1])) : 10;
    if (N < 5) N = 5;

    Matrix A = random_matrix(N, 42);
    Matrix B = random_matrix(N, 1337);

    auto t0 = std::chrono::high_resolution_clock::now();
    auto C_naive = multiply_naive(A, B);
    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "Naive multiplication time: "
              << std::chrono::duration<double>(t1 - t0).count() << " s\n";

    std::cout << "block_size,threads,time\n";
    for (size_t block = 1; block <= N; ++block) {
        size_t blocks = (N + block - 1) / block;
        size_t thread_cnt = blocks * blocks;
        auto start = std::chrono::high_resolution_clock::now();
        auto C = multiply_windows(A, B, block);
        auto end = std::chrono::high_resolution_clock::now();
        double t = std::chrono::duration<double>(end - start).count();
        std::cout << block << "," << thread_cnt << "," << t << "\n";
        if (N <= 10 && C != C_naive) {
            std::cerr << "Mismatch at block " << block << "\n";
            return 1;
        }
    }
    return 0;
}
