#include <iostream>
#include "B.h"

int main() {
    std::cout << "B = " << getB() << std::endl;
    return 0;
}
